def numbers(file_name):
    list1 = []
    list2 = []
    list3 = []
    with open(file_name, 'r') as f:
        for i in f:
            if i == '\n':
                continue
            else:
                list1.append(i)

        for j in list1:
            if j[0] == 'u':
                list2.append(j)
            else:
                continue

        for i in list2:
            num = int(i[9:12])
            list3.append(num)
    sum_all = 0
    for i in list3:
        sum_all += i
    result = sum_all/50
    
    return result

int_calls = numbers("hello.txt")
syscall = numbers("hello2.txt")

print("int_calls          = " , int_calls)
print("syscall            = " , syscall)

percentage_speedup = (int_calls - syscall) * 100 / int_calls

print("percentage_speedup = " , percentage_speedup)